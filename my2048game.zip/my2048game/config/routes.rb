Rails.application.routes.draw do
  get 'games/index'
  root 'home#index'
end

get '/game', to: 'games#index'
