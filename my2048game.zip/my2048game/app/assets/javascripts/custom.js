// app/assets/javascripts/custom.js
document.addEventListener("DOMContentLoaded", function() {
    var playButton = document.getElementById("play-button");
    if(playButton) {
        playButton.addEventListener("click", function() {
            // 这里添加点击按钮后的动作，比如跳转到游戏页面
            window.location.href = '/game'; // 假设游戏页面的URL是'/game'
        });
    }
});
